# realworld.svelte.dev

## 1.0.1-next.0
### Patch Changes

- 4aa5a73: Future-proof prepare argument
